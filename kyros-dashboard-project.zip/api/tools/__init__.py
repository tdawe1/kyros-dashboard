"""
Tools module for Kyros Dashboard

This module contains all the individual tools that can be plugged into the system.
Each tool is self-contained with its own router, generator, and schemas.
"""
